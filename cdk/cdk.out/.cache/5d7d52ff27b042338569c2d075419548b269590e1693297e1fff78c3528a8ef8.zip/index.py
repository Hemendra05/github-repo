import os

def handler(event, context):
    # os.system("pip install boto3")
    return { 
        "statusCode": 200,
        "body": "Hello World!!"
    }

